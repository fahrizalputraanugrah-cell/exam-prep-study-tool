# ai-code-teacher
An AI-powered code teacher that reviews your code, provides feedback, and explains what's wrong
